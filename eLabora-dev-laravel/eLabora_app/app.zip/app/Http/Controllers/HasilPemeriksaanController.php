<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\ExpressApiService;

class HasilPemeriksaanController extends Controller
{
    // LIST HASIL PEMERIKSAAN
    public function index(Request $request, ExpressApiService $api)
    {
        $kategori = $request->query('kategori');

        //AMBIL PASIEN ID (INI PENTING)
        $pasienId = session('auth_akun_id');

        if (!$pasienId) {
            return back()->with('error', 'Pasien tidak ditemukan di session');
        }

        //PAKAI ENDPOINT YANG BENAR
        $response = $api->examsByPatient($pasienId);

        $list = $response->successful()
            ? collect($response->json()['data'])
                ->when(
                    $kategori,
                    fn($q) =>
                    $q->where('kategori_nama', $kategori)
                )
                ->values()
                ->all()
            : [];

        return view('pages.pasien.hasilPemeriksaan', [
            'list' => $list,
            'kategoriAktif' => $kategori
        ]);
    }

    // DETAIL HASIL PEMERIKSAAN
    public function detail(ExpressApiService $api, int $id)
    {
        $response = $api->examDetail($id);

        if (!$response->successful()) {
            return back()->with('error', 'Data hasil pemeriksaan tidak ditemukan');
        }

        return view('pages.pasien.hasilPemeriksaanDetail', [
            'hasil' => $response->json()['data']
        ]);
    }
    // DOWNLOAD
    public function download(ExpressApiService $api, int $id)
    {
        $response = $api->examDownload($id);

        if (!$response->successful()) {
            abort(404);
        }

        return response($response->body(), 200)
            ->header('Content-Type', $response->header('Content-Type'))
            ->header(
                'Content-Disposition',
                'attachment; filename="hasil-pemeriksaan.pdf"'
            );
    }
}
