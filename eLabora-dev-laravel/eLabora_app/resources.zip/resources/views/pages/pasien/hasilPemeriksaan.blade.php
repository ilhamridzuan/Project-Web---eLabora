@extends('layouts.app', ['sidebar' => 'pasien'])

@section('title', 'Hasil Pemeriksaan')

@section('content')

    <body class="bg-[#f6f8fc] ml-[260px] min-h-screen">

        <div class="p-8">

            {{-- Search --}}
            <div class="mb-6">
                <input type="text" placeholder="Cari berdasarkan nomor lab"
                    class="w-full px-4 py-3 mb-4 border border-[#dce1f2] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                    disabled>

                {{-- Filter --}}
                <div class="flex flex-wrap gap-3">
                    <a href="{{ route('hasil.pemeriksaan') }}" class="px-6 py-2 rounded-xl text-sm
               {{ empty($kategoriAktif) ? 'bg-indigo-600 text-white' : 'bg-[#eef1f8]' }}">
                        Semua
                    </a>

                    <a href="{{ route('hasil.pemeriksaan', ['kategori' => 'Patologi']) }}" class="px-6 py-2 rounded-xl text-sm
               {{ $kategoriAktif === 'Patologi' ? 'bg-indigo-600 text-white' : 'bg-[#eef1f8]' }}">
                        Patologi
                    </a>

                    <a href="{{ route('hasil.pemeriksaan', ['kategori' => 'Anatomi']) }}" class="px-6 py-2 rounded-xl text-sm
               {{ $kategoriAktif === 'Anatomi' ? 'bg-indigo-600 text-white' : 'bg-[#eef1f8]' }}">
                        Anatomi
                    </a>

                    <a href="{{ route('hasil.pemeriksaan', ['kategori' => 'Mikrobiologi']) }}" class="px-6 py-2 rounded-xl text-sm
               {{ $kategoriAktif === 'Mikrobiologi' ? 'bg-indigo-600 text-white' : 'bg-[#eef1f8]' }}">
                        Mikrobiologi
                    </a>
                </div>

                <div class="mt-8 space-y-4">
                    @forelse($list ?? [] as $item)
                        <a href="{{ route('hasil.pemeriksaan.detail', $item['id']) }}"
                            class="block bg-white rounded-xl p-5 shadow hover:bg-gray-50 transition">

                            <div class="flex justify-between items-center">
                                <div>
                                    <h4 class="font-semibold text-gray-800">
                                        Pemeriksaan {{ $item['kategori'] }}
                                    </h4>
                                    <p class="text-sm text-gray-500">
                                        {{ $item['tanggal'] }}
                                    </p>
                                    <p class="text-sm text-gray-400">
                                        {{ $item['no_lab'] }}
                                    </p>
                                </div>
                                <span class="text-gray-400">›</span>
                            </div>

                        </a>
                    @empty
                        <p class="text-gray-500 text-center">
                            Belum ada hasil pemeriksaan
                        </p>
                    @endforelse
                </div>

            </div>
        </div>

    </body>
@endsection